package components;

public class Ground extends Component {
}
